package com.example.gay_stickers

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
